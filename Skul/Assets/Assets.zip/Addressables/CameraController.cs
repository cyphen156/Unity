using UnityEngine;

/// <summary>
/// �÷��̾ ���� �Ÿ� ����� ���� ���󰡴� ī�޶� ��Ʈ�ѷ�
/// </summary>
public class CameraController : MonoBehaviour
{
    public float maxDistX = 2.0f;
    public float maxDistY = 3.0f;
    public float followSpeed = 5f;

    private Transform player;

    private void Start()
    {
        GameObject playerObj = GameObject.FindGameObjectWithTag("Player");
        if (playerObj != null)
        {
            player = playerObj.transform;
        }
    }

    private void LateUpdate()
    {
        if (player == null)
        {
            return;
        }

        Vector3 camPos = transform.position;
        Vector3 playerPos = player.position;
        Vector3 diff = playerPos - camPos;
        Vector3 targetPos = camPos;

        // X ���� �˻�
        if (Mathf.Abs(diff.x) > maxDistX)
        {
            targetPos.x = Mathf.Lerp(camPos.x, playerPos.x, followSpeed * Time.deltaTime);
        }

        // Y ���� �˻�
        if (Mathf.Abs(diff.y) > maxDistY)
        {
            targetPos.y = Mathf.Lerp(camPos.y, playerPos.y, followSpeed * Time.deltaTime);
        }

        // Z ����
        targetPos.z = camPos.z;

        transform.position = targetPos;
    }
}