using UnityEngine;

public class AudioClips : MonoBehaviour
{
    public AudioClip Chapter1BGM;
    public AudioClip DefaultSkill1BGM;
    public AudioClip DarkPaladinSkill1BGM;
    public AudioClip DarkPaladinSkill2BGM;

    public AudioClip Attack1;
    public AudioClip JumpAttack;
    public AudioClip Dash;
    public AudioClip Jump;

    public static AudioClips instance;

    private void Awake()
    {
        if (instance == null)
        {
            instance = this;
        }    
    }

    private void Start()
    {
        SoundManager.instance.PlayEmbeddedBGM(Chapter1BGM);

    }
}
