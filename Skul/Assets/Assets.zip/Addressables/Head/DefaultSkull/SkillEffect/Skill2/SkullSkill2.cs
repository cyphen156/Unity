using UnityEngine;

public class SkullSkill2 : MonoBehaviour
{
    GameObject go;
    void Start()
    {
        go = GameObject.FindGameObjectWithTag("DefaultSkill1");

        if (go != null)
        { 
            Transform targetPoint = go.transform;
            GameObject player = GameObject.FindGameObjectWithTag("Player");

            player.GetComponent<PlayerController>().WarpPlayer(targetPoint);
        }
    }
}
