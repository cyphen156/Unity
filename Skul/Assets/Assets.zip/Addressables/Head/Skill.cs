using Unity.VisualScripting;
using UnityEngine;

public class Skill : MonoBehaviour
{
    private bool canHit = true;
    public float destroyTime = 0f;
    public float delayTime = 0f;
    public float currentTme;
    public float damage = 1.5f;
    public Vector3 moveSpeed = Vector3.zero;

    private Animator animator;
    SpriteRenderer sr;

    private void Awake()
    {
        currentTme = 0f;
        sr = GetComponent<SpriteRenderer>();
        animator = GetComponent<Animator>();
    }

    private void Start()
    {
        sr.enabled = false;
    }
    private void Update()
    {
        currentTme += Time.deltaTime;
        if (currentTme >= delayTime)
        {
            sr.enabled = true;

            transform.position += moveSpeed * Time.deltaTime;
            if (animator != null)
            {
                animator.Play("SkillAnim");
                StartCoroutine(DestroyAfterAnimation());
            }
            else
            {
                Destroy(gameObject, destroyTime);
            }
        }
    }

    public void SetDirection(Vector3 direction)
    {
        if (direction == Vector3.left)
        {
            if (sr != null)
            {
                sr.flipX = true;
            }
        }
        moveSpeed = direction.normalized * moveSpeed.x;
    }

    public void AddDamage(float playerDamage)
    {
        damage *= playerDamage;
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Monster") && canHit)
        {
            canHit = false;
            // ������ ����
            //collision.gameObject.GetComponent<MonsterStatus>().TakeDamage(damage);
        }
    }

    private System.Collections.IEnumerator DestroyAfterAnimation()
    {
        yield return null;
        AnimatorStateInfo stateInfo = animator.GetCurrentAnimatorStateInfo(0);
        yield return new WaitForSeconds(stateInfo.length);
        Destroy(gameObject);
    }
}